<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

// تحديد اللغة الافتراضية
$current_lang = isset($_GET['lang']) ? $_GET['lang'] : 'ar';
$is_rtl = $current_lang === 'ar';

// تحميل ملفات اللغة
$translations = loadLanguage($current_lang);
?>
<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>" dir="<?php echo $is_rtl ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $translations['site_title']; ?> - <?php echo $translations['home']; ?></title>
    <meta name="description" content="<?php echo $translations['site_description']; ?>">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e40af',
                        secondary: '#f59e0b',
                        accent: '#10b981'
                    },
                    fontFamily: {
                        'arabic': ['Cairo', 'sans-serif'],
                        'english': ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
</head>
<body class="<?php echo $is_rtl ? 'font-arabic' : 'font-english'; ?> bg-gray-50">
    <!-- Header -->
    <?php include 'includes/header.php'; ?>
    
    <!-- Hero Section -->
    <section class="relative bg-gradient-to-r from-primary to-blue-800 text-white py-20">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div class="<?php echo $is_rtl ? 'text-right' : 'text-left'; ?>">
                    <h1 class="text-4xl lg:text-6xl font-bold mb-6">
                        <?php echo $translations['hero_title']; ?>
                    </h1>
                    <p class="text-xl mb-8 text-blue-100">
                        <?php echo $translations['hero_subtitle']; ?>
                    </p>
                    <div class="flex <?php echo $is_rtl ? 'justify-end' : 'justify-start'; ?> gap-4">
                        <a href="#services" class="bg-secondary hover:bg-yellow-600 text-white px-8 py-3 rounded-lg font-semibold transition duration-300">
                            <?php echo $translations['get_started']; ?>
                        </a>
                        <a href="#about" class="border-2 border-white text-white hover:bg-white hover:text-primary px-8 py-3 rounded-lg font-semibold transition duration-300">
                            <?php echo $translations['learn_more']; ?>
                        </a>
                    </div>
                </div>
                <div class="hidden lg:block">
                    <img src="assets/images/hero-image.png" alt="أصالة سنتر" class="w-full h-auto">
                </div>
            </div>
        </div>
    </section>
    
    <!-- Services Section -->
    <section id="services" class="py-20 bg-white">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-3xl lg:text-4xl font-bold text-gray-800 mb-4">
                    <?php echo $translations['our_services']; ?>
                </h2>
                <p class="text-lg text-gray-600 max-w-2xl mx-auto">
                    <?php echo $translations['services_description']; ?>
                </p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Service Card 1 -->
                <div class="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition duration-300 border border-gray-100">
                    <div class="w-16 h-16 bg-primary rounded-lg flex items-center justify-center mb-6">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-4">
                        <?php echo $translations['service_1_title']; ?>
                    </h3>
                    <p class="text-gray-600">
                        <?php echo $translations['service_1_description']; ?>
                    </p>
                </div>
                
                <!-- Service Card 2 -->
                <div class="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition duration-300 border border-gray-100">
                    <div class="w-16 h-16 bg-secondary rounded-lg flex items-center justify-center mb-6">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-4">
                        <?php echo $translations['service_2_title']; ?>
                    </h3>
                    <p class="text-gray-600">
                        <?php echo $translations['service_2_description']; ?>
                    </p>
                </div>
                
                <!-- Service Card 3 -->
                <div class="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition duration-300 border border-gray-100">
                    <div class="w-16 h-16 bg-accent rounded-lg flex items-center justify-center mb-6">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-4">
                        <?php echo $translations['service_3_title']; ?>
                    </h3>
                    <p class="text-gray-600">
                        <?php echo $translations['service_3_description']; ?>
                    </p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- About Section -->
    <section id="about" class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div>
                    <img src="assets/images/about-image.jpg" alt="عن الشركة" class="rounded-xl shadow-lg">
                </div>
                <div class="<?php echo $is_rtl ? 'text-right' : 'text-left'; ?>">
                    <h2 class="text-3xl lg:text-4xl font-bold text-gray-800 mb-6">
                        <?php echo $translations['about_title']; ?>
                    </h2>
                    <p class="text-lg text-gray-600 mb-6">
                        <?php echo $translations['about_description']; ?>
                    </p>
                    <div class="grid grid-cols-2 gap-6">
                        <div class="text-center">
                            <div class="text-3xl font-bold text-primary mb-2">150+</div>
                            <div class="text-gray-600"><?php echo $translations['projects_completed']; ?></div>
                        </div>
                        <div class="text-center">
                            <div class="text-3xl font-bold text-primary mb-2">50+</div>
                            <div class="text-gray-600"><?php echo $translations['happy_clients']; ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Contact Section -->
    <section id="contact" class="py-20 bg-white">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-3xl lg:text-4xl font-bold text-gray-800 mb-4">
                    <?php echo $translations['contact_us']; ?>
                </h2>
                <p class="text-lg text-gray-600">
                    <?php echo $translations['contact_description']; ?>
                </p>
            </div>
            
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
                <div>
                    <form class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-gray-700 font-semibold mb-2">
                                    <?php echo $translations['first_name']; ?>
                                </label>
                                <input type="text" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
                            </div>
                            <div>
                                <label class="block text-gray-700 font-semibold mb-2">
                                    <?php echo $translations['last_name']; ?>
                                </label>
                                <input type="text" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
                            </div>
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">
                                <?php echo $translations['email']; ?>
                            </label>
                            <input type="email" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
                        </div>
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">
                                <?php echo $translations['message']; ?>
                            </label>
                            <textarea rows="5" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"></textarea>
                        </div>
                        <button type="submit" class="w-full bg-primary hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition duration-300">
                            <?php echo $translations['send_message']; ?>
                        </button>
                    </form>
                </div>
                
                <div class="<?php echo $is_rtl ? 'text-right' : 'text-left'; ?>">
                    <div class="space-y-6">
                        <div class="flex <?php echo $is_rtl ? 'flex-row-reverse' : 'flex-row'; ?> items-center">
                            <div class="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mr-4">
                                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                </svg>
                            </div>
                            <div>
                                <h3 class="font-semibold text-gray-800"><?php echo $translations['address']; ?></h3>
                                <p class="text-gray-600"><?php echo $translations['address_value']; ?></p>
                            </div>
                        </div>
                        
                        <div class="flex <?php echo $is_rtl ? 'flex-row-reverse' : 'flex-row'; ?> items-center">
                            <div class="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center mr-4">
                                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
                                </svg>
                            </div>
                            <div>
                                <h3 class="font-semibold text-gray-800"><?php echo $translations['phone']; ?></h3>
                                <p class="text-gray-600">+966 50 123 4567</p>
                            </div>
                        </div>
                        
                        <div class="flex <?php echo $is_rtl ? 'flex-row-reverse' : 'flex-row'; ?> items-center">
                            <div class="w-12 h-12 bg-accent rounded-lg flex items-center justify-center mr-4">
                                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                                </svg>
                            </div>
                            <div>
                                <h3 class="font-semibold text-gray-800"><?php echo $translations['email']; ?></h3>
                                <p class="text-gray-600">info@asalacenter.com</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- Custom JavaScript -->
    <script src="assets/js/main.js"></script>
</body>
</html>

