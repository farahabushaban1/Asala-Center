-- Asala Center Database Schema
-- Created: 2025
-- Character Set: utf8mb4
-- Collation: utf8mb4_unicode_ci

-- Create database if not exists
CREATE DATABASE IF NOT EXISTS `asala_center` 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE `asala_center`;

-- Users table
CREATE TABLE `users` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(255) NOT NULL,
    `email` varchar(255) NOT NULL UNIQUE,
    `password` varchar(255) NOT NULL,
    `role` enum('admin', 'editor', 'user') NOT NULL DEFAULT 'user',
    `status` enum('active', 'inactive', 'pending') NOT NULL DEFAULT 'active',
    `avatar` varchar(255) DEFAULT NULL,
    `phone` varchar(20) DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `last_login` timestamp NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_email` (`email`),
    KEY `idx_status` (`status`),
    KEY `idx_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Services table
CREATE TABLE `services` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `title_ar` varchar(255) NOT NULL,
    `title_en` varchar(255) NOT NULL,
    `description_ar` text NOT NULL,
    `description_en` text NOT NULL,
    `icon` varchar(255) DEFAULT NULL,
    `image` varchar(255) DEFAULT NULL,
    `sort_order` int(11) NOT NULL DEFAULT 0,
    `status` enum('active', 'inactive') NOT NULL DEFAULT 'active',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_status` (`status`),
    KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Projects table
CREATE TABLE `projects` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `title_ar` varchar(255) NOT NULL,
    `title_en` varchar(255) NOT NULL,
    `description_ar` text NOT NULL,
    `description_en` text NOT NULL,
    `client` varchar(255) DEFAULT NULL,
    `category` varchar(100) DEFAULT NULL,
    `image` varchar(255) DEFAULT NULL,
    `gallery` json DEFAULT NULL,
    `url` varchar(255) DEFAULT NULL,
    `technologies` json DEFAULT NULL,
    `completion_date` date DEFAULT NULL,
    `status` enum('completed', 'in_progress', 'planned') NOT NULL DEFAULT 'completed',
    `featured` tinyint(1) NOT NULL DEFAULT 0,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_status` (`status`),
    KEY `idx_featured` (`featured`),
    KEY `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Contact messages table
CREATE TABLE `contact_messages` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `first_name` varchar(100) NOT NULL,
    `last_name` varchar(100) NOT NULL,
    `email` varchar(255) NOT NULL,
    `phone` varchar(20) DEFAULT NULL,
    `subject` varchar(255) DEFAULT NULL,
    `message` text NOT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `user_agent` text DEFAULT NULL,
    `status` enum('new', 'read', 'replied', 'spam') NOT NULL DEFAULT 'new',
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_status` (`status`),
    KEY `idx_email` (`email`),
    KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Settings table
CREATE TABLE `settings` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `key` varchar(100) NOT NULL UNIQUE,
    `value` text NOT NULL,
    `type` enum('string', 'number', 'boolean', 'json') NOT NULL DEFAULT 'string',
    `description` varchar(255) DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Pages table
CREATE TABLE `pages` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `title_ar` varchar(255) NOT NULL,
    `title_en` varchar(255) NOT NULL,
    `slug_ar` varchar(255) NOT NULL,
    `slug_en` varchar(255) NOT NULL,
    `content_ar` longtext NOT NULL,
    `content_en` longtext NOT NULL,
    `meta_description_ar` varchar(500) DEFAULT NULL,
    `meta_description_en` varchar(500) DEFAULT NULL,
    `meta_keywords_ar` varchar(500) DEFAULT NULL,
    `meta_keywords_en` varchar(500) DEFAULT NULL,
    `status` enum('published', 'draft', 'private') NOT NULL DEFAULT 'draft',
    `created_by` int(11) NOT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_slug_ar` (`slug_ar`),
    KEY `idx_slug_en` (`slug_en`),
    KEY `idx_status` (`status`),
    KEY `idx_created_by` (`created_by`),
    FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Blog posts table
CREATE TABLE `blog_posts` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `title_ar` varchar(255) NOT NULL,
    `title_en` varchar(255) NOT NULL,
    `slug_ar` varchar(255) NOT NULL,
    `slug_en` varchar(255) NOT NULL,
    `excerpt_ar` text DEFAULT NULL,
    `excerpt_en` text DEFAULT NULL,
    `content_ar` longtext NOT NULL,
    `content_en` longtext NOT NULL,
    `featured_image` varchar(255) DEFAULT NULL,
    `meta_description_ar` varchar(500) DEFAULT NULL,
    `meta_description_en` varchar(500) DEFAULT NULL,
    `meta_keywords_ar` varchar(500) DEFAULT NULL,
    `meta_keywords_en` varchar(500) DEFAULT NULL,
    `author_id` int(11) NOT NULL,
    `status` enum('published', 'draft', 'private') NOT NULL DEFAULT 'draft',
    `published_at` timestamp NULL DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_slug_ar` (`slug_ar`),
    KEY `idx_slug_en` (`slug_en`),
    KEY `idx_status` (`status`),
    KEY `idx_author_id` (`author_id`),
    KEY `idx_published_at` (`published_at`),
    FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Blog categories table
CREATE TABLE `blog_categories` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `name_ar` varchar(100) NOT NULL,
    `name_en` varchar(100) NOT NULL,
    `slug_ar` varchar(100) NOT NULL,
    `slug_en` varchar(100) NOT NULL,
    `description_ar` text DEFAULT NULL,
    `description_en` text DEFAULT NULL,
    `parent_id` int(11) DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_slug_ar` (`slug_ar`),
    KEY `idx_slug_en` (`slug_en`),
    KEY `idx_parent_id` (`parent_id`),
    FOREIGN KEY (`parent_id`) REFERENCES `blog_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Blog post categories relationship table
CREATE TABLE `blog_post_categories` (
    `post_id` int(11) NOT NULL,
    `category_id` int(11) NOT NULL,
    PRIMARY KEY (`post_id`, `category_id`),
    FOREIGN KEY (`post_id`) REFERENCES `blog_posts` (`id`) ON DELETE CASCADE,
    FOREIGN KEY (`category_id`) REFERENCES `blog_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Files table for uploaded files
CREATE TABLE `files` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `filename` varchar(255) NOT NULL,
    `original_name` varchar(255) NOT NULL,
    `file_path` varchar(500) NOT NULL,
    `file_size` bigint(20) NOT NULL,
    `mime_type` varchar(100) NOT NULL,
    `extension` varchar(10) NOT NULL,
    `uploaded_by` int(11) NOT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_uploaded_by` (`uploaded_by`),
    KEY `idx_mime_type` (`mime_type`),
    KEY `idx_created_at` (`created_at`),
    FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Activity log table
CREATE TABLE `activity_log` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `user_id` int(11) DEFAULT NULL,
    `action` varchar(100) NOT NULL,
    `table_name` varchar(100) DEFAULT NULL,
    `record_id` int(11) DEFAULT NULL,
    `old_values` json DEFAULT NULL,
    `new_values` json DEFAULT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `user_agent` text DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_action` (`action`),
    KEY `idx_table_name` (`table_name`),
    KEY `idx_created_at` (`created_at`),
    FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default admin user
INSERT INTO `users` (`name`, `email`, `password`, `role`, `status`) VALUES 
('مدير النظام', 'admin@asalacenter.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active');

-- Insert default services
INSERT INTO `services` (`title_ar`, `title_en`, `description_ar`, `description_en`, `icon`, `sort_order`, `status`) VALUES
('تطوير المواقع الإلكترونية', 'Web Development', 'تصميم وتطوير مواقع إلكترونية احترافية ومتجاوبة مع جميع الأجهزة', 'Design and development of professional and responsive websites for all devices', 'web', 1, 'active'),
('تطبيقات الموبايل', 'Mobile Applications', 'تطوير تطبيقات الهواتف الذكية للأندرويد والآيفون', 'Development of smartphone applications for Android and iPhone', 'mobile', 2, 'active'),
('الحلول التقنية', 'Technical Solutions', 'حلول تقنية متكاملة لتحسين أداء أعمالك', 'Integrated technical solutions to improve your business performance', 'tech', 3, 'active');

-- Insert default settings
INSERT INTO `settings` (`key`, `value`, `type`, `description`) VALUES
('site_name_ar', 'أصالة سنتر', 'string', 'اسم الموقع باللغة العربية'),
('site_name_en', 'Asala Center', 'string', 'اسم الموقع باللغة الإنجليزية'),
('site_description_ar', 'موقع إلكتروني احترافي متعدد اللغات يعرض خدمات ومشاريع الشركة', 'string', 'وصف الموقع باللغة العربية'),
('site_description_en', 'Professional multilingual website showcasing company services and projects', 'string', 'وصف الموقع باللغة الإنجليزية'),
('site_email', 'info@asalacenter.com', 'string', 'البريد الإلكتروني الرئيسي للموقع'),
('site_phone', '+966 50 123 4567', 'string', 'رقم الهاتف الرئيسي'),
('site_address_ar', 'الرياض، المملكة العربية السعودية', 'string', 'عنوان الشركة باللغة العربية'),
('site_address_en', 'Riyadh, Kingdom of Saudi Arabia', 'string', 'عنوان الشركة باللغة الإنجليزية'),
('social_facebook', '', 'string', 'رابط صفحة فيسبوك'),
('social_twitter', '', 'string', 'رابط حساب تويتر'),
('social_instagram', '', 'string', 'رابط حساب انستغرام'),
('social_linkedin', '', 'string', 'رابط حساب لينكد إن'),
('google_analytics_id', '', 'string', 'معرف Google Analytics'),
('maintenance_mode', '0', 'boolean', 'وضع الصيانة'),
('default_language', 'ar', 'string', 'اللغة الافتراضية للموقع'),
('items_per_page', '10', 'number', 'عدد العناصر في الصفحة الواحدة'),
('file_upload_max_size', '5242880', 'number', 'الحد الأقصى لحجم الملفات المرفوعة (بالبايت)'),
('allowed_file_types', '["jpg","jpeg","png","gif","pdf","doc","docx","xls","xlsx"]', 'json', 'أنواع الملفات المسموح برفعها');

-- Insert default pages
INSERT INTO `pages` (`title_ar`, `title_en`, `slug_ar`, `slug_en`, `content_ar`, `content_en`, `status`, `created_by`) VALUES
('سياسة الخصوصية', 'Privacy Policy', 'privacy-policy', 'privacy-policy', '<h2>سياسة الخصوصية</h2><p>محتوى سياسة الخصوصية...</p>', '<h2>Privacy Policy</h2><p>Privacy policy content...</p>', 'published', 1),
('شروط الاستخدام', 'Terms of Service', 'terms-of-service', 'terms-of-service', '<h2>شروط الاستخدام</h2><p>محتوى شروط الاستخدام...</p>', '<h2>Terms of Service</h2><p>Terms of service content...</p>', 'published', 1),
('عن الشركة', 'About Us', 'about-us', 'about-us', '<h2>عن الشركة</h2><p>محتوى صفحة عن الشركة...</p>', '<h2>About Us</h2><p>About us page content...</p>', 'published', 1);

-- Create indexes for better performance
CREATE INDEX `idx_contact_messages_status_created` ON `contact_messages` (`status`, `created_at`);
CREATE INDEX `idx_blog_posts_status_published` ON `blog_posts` (`status`, `published_at`);
CREATE INDEX `idx_files_uploaded_by_created` ON `files` (`uploaded_by`, `created_at`);
CREATE INDEX `idx_activity_log_user_created` ON `activity_log` (`user_id`, `created_at`);

-- Create views for common queries
CREATE VIEW `v_active_services` AS
SELECT * FROM `services` WHERE `status` = 'active' ORDER BY `sort_order` ASC;

CREATE VIEW `v_featured_projects` AS
SELECT * FROM `projects` WHERE `status` = 'completed' AND `featured` = 1 ORDER BY `completion_date` DESC;

CREATE VIEW `v_recent_blog_posts` AS
SELECT * FROM `blog_posts` WHERE `status` = 'published' AND `published_at` IS NOT NULL ORDER BY `published_at` DESC LIMIT 10;

-- Create stored procedures
DELIMITER //

CREATE PROCEDURE `GetContactStats`()
BEGIN
    SELECT 
        COUNT(*) as total_messages,
        COUNT(CASE WHEN status = 'new' THEN 1 END) as new_messages,
        COUNT(CASE WHEN status = 'read' THEN 1 END) as read_messages,
        COUNT(CASE WHEN status = 'replied' THEN 1 END) as replied_messages
    FROM contact_messages;
END //

CREATE PROCEDURE `GetProjectStats`()
BEGIN
    SELECT 
        COUNT(*) as total_projects,
        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_projects,
        COUNT(CASE WHEN status = 'in_progress' THEN 1 END) as in_progress_projects,
        COUNT(CASE WHEN status = 'planned' THEN 1 END) as planned_projects
    FROM projects;
END //

DELIMITER ;

-- Grant permissions (adjust as needed)
-- GRANT ALL PRIVILEGES ON asala_center.* TO 'asala_user'@'localhost' IDENTIFIED BY 'your_password';
-- FLUSH PRIVILEGES;

