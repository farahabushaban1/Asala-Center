<?php
return [
    // Site Information
    'site_title' => 'Asala Center',
    'site_description' => 'Professional multilingual website showcasing company services and projects',
    'home' => 'Home',
    
    // Main Menu
    'menu_home' => 'Home',
    'menu_services' => 'Services',
    'menu_about' => 'About',
    'menu_projects' => 'Projects',
    'menu_contact' => 'Contact',
    'menu_admin' => 'Dashboard',
    'menu_login' => 'Login',
    'menu_logout' => 'Logout',
    
    // Hero Section
    'hero_title' => 'Asala Center',
    'hero_subtitle' => 'We provide innovative and advanced technical solutions to achieve your digital vision',
    'get_started' => 'Get Started',
    'learn_more' => 'Learn More',
    
    // Services Section
    'our_services' => 'Our Services',
    'services_description' => 'We provide a comprehensive range of advanced technical services to develop your business',
    'service_1_title' => 'Web Development',
    'service_1_description' => 'Design and development of professional and responsive websites for all devices',
    'service_2_title' => 'Mobile Applications',
    'service_2_description' => 'Development of smartphone applications for Android and iPhone',
    'service_3_title' => 'Technical Solutions',
    'service_3_description' => 'Integrated technical solutions to improve your business performance',
    
    // About Section
    'about_title' => 'About Asala Center',
    'about_description' => 'A leading technology company specialized in developing advanced digital solutions. We have been working for years to provide high-quality services to our valued clients.',
    'projects_completed' => 'Completed Projects',
    'happy_clients' => 'Happy Clients',
    
    // Contact Section
    'contact_us' => 'Contact Us',
    'contact_description' => 'We are here to help you achieve your digital vision',
    'first_name' => 'First Name',
    'last_name' => 'Last Name',
    'email' => 'Email',
    'phone' => 'Phone Number',
    'message' => 'Message',
    'send_message' => 'Send Message',
    'address' => 'Address',
    'address_value' => 'Riyadh, Kingdom of Saudi Arabia',
    
    // Footer
    'footer_description' => 'Asala Center - A leading technology company in developing digital solutions',
    'quick_links' => 'Quick Links',
    'contact_info' => 'Contact Information',
    'follow_us' => 'Follow Us',
    'all_rights_reserved' => 'All Rights Reserved',
    
    // System Messages
    'message_sent_success' => 'Your message has been sent successfully',
    'message_sent_error' => 'An error occurred while sending the message',
    'invalid_email' => 'Invalid email address',
    'required_fields' => 'Please fill in all required fields',
    
    // Dashboard
    'dashboard' => 'Dashboard',
    'users' => 'Users',
    'settings' => 'Settings',
    'logout' => 'Logout',
    'welcome' => 'Welcome',
    
    // Buttons
    'save' => 'Save',
    'cancel' => 'Cancel',
    'edit' => 'Edit',
    'delete' => 'Delete',
    'add' => 'Add',
    'search' => 'Search',
    'filter' => 'Filter',
    'export' => 'Export',
    'import' => 'Import',
    
    // Status
    'active' => 'Active',
    'inactive' => 'Inactive',
    'pending' => 'Pending',
    'completed' => 'Completed',
    'cancelled' => 'Cancelled',
    
    // Dates
    'today' => 'Today',
    'yesterday' => 'Yesterday',
    'tomorrow' => 'Tomorrow',
    'this_week' => 'This Week',
    'this_month' => 'This Month',
    'this_year' => 'This Year',
    
    // Errors
    'error_404' => 'Page Not Found',
    'error_403' => 'Access Denied',
    'error_500' => 'Server Error',
    'page_not_found' => 'The page you are looking for does not exist',
    'go_back_home' => 'Go Back Home',
    
    // Success
    'success' => 'Success',
    'operation_completed' => 'Operation completed successfully',
    'data_saved' => 'Data saved successfully',
    'data_deleted' => 'Data deleted successfully',
    
    // Warnings
    'warning' => 'Warning',
    'confirm_delete' => 'Are you sure you want to delete this item?',
    'unsaved_changes' => 'You have unsaved changes',
    
    // Information
    'info' => 'Information',
    'loading' => 'Loading...',
    'no_data' => 'No data available',
    'no_results' => 'No results found',
    
    // Verification
    'please_wait' => 'Please wait...',
    'processing' => 'Processing...',
    'uploading' => 'Uploading...',
    'downloading' => 'Downloading...',
    
    // Forms
    'form_required' => 'Required Fields',
    'form_optional' => 'Optional Fields',
    'form_submit' => 'Submit Form',
    'form_reset' => 'Reset',
    
    // Search
    'search_placeholder' => 'Search here...',
    'search_results' => 'Search Results',
    'search_no_results' => 'No search results found',
    
    // Pages
    'page' => 'Page',
    'of' => 'of',
    'showing' => 'Showing',
    'to' => 'to',
    'entries' => 'entries',
    'per_page' => 'per page',
    
    // Navigation
    'previous' => 'Previous',
    'next' => 'Next',
    'first' => 'First',
    'last' => 'Last',
    
    // Time
    'seconds_ago' => 'seconds ago',
    'minutes_ago' => 'minutes ago',
    'hours_ago' => 'hours ago',
    'days_ago' => 'days ago',
    'weeks_ago' => 'weeks ago',
    'months_ago' => 'months ago',
    'years_ago' => 'years ago',
    
    // Currency
    'currency' => 'SAR',
    'price' => 'Price',
    'total' => 'Total',
    'subtotal' => 'Subtotal',
    'tax' => 'Tax',
    'discount' => 'Discount',
    'final_total' => 'Final Total',
];
?>

