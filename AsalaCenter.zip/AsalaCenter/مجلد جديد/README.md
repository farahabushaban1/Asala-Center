
# أصالة سنتر - 2025 Edition

موقع إلكتروني احترافي متعدد اللغات (عربي/إنجليزي) يعرض خدمات ومشاريع الشركة مع لوحة تحكم ديناميكية.

## 🚀 المميزات

- 🌐 **دعم متعدد اللغات** (عربي/إنجليزي)
- 🎨 **واجهة مستخدم حديثة** باستخدام **Tailwind CSS**
- 🔐 **لوحة تحكم آمنة**
- 📱 **تصميم متجاوب بالكامل**
- 🖼 **إدارة المحتوى بشكل ديناميكي**
- 🔄 **دعم اللغة من اليمين لليسار (RTL) واليسار لليمين (LTR)**
- 📊 **تحسين محركات البحث (SEO)**
- 🔍 **دمج مع Google Analytics**
- ⚡ **أداء محسن** مع التخزين المؤقت والضغط
- 🔒 **أمان عالي** مع حماية من XSS و CSRF

## 🛠 التقنيات المستخدمة

- **الواجهة الأمامية**: HTML5، CSS3، JavaScript، Tailwind CSS
- **الواجهة الخلفية**: PHP 7.4+
- **قاعدة البيانات**: MySQL 5.7+
- **الدعم متعدد اللغات**: نظام لغة ديناميكي
- **لوحة التحكم**: تم بناءها خصيصًا
- **إدارة التبعيات**: Composer
- **أدوات البناء**: npm/yarn

## 📁 هيكل المشروع

```
AsalaCenter/
├── admin/              # ملفات لوحة التحكم
├── assets/             # الأصول الثابتة
│   ├── css/            # ملفات الأنماط
│   ├── js/             # ملفات جافا سكريبت
│   └── images/         # صور الموقع
├── config/             # ملفات التكوين
├── database/           # ملفات قاعدة البيانات
├── includes/           # ملفات PHP المساعدة
├── languages/          # ملفات اللغة
├── uploads/            # المحتوى المرفوع من المستخدمين
├── vendor/             # التبعيات (Composer)
├── .htaccess           # إعدادات Apache
├── composer.json       # إعدادات Composer
├── package.json        # إعدادات npm
├── tailwind.config.js  # إعدادات Tailwind CSS
└── README.md           # ملف التوثيق
```

## 🔧 كيفية التثبيت

### المتطلبات الأساسية
- PHP 7.4 أو أحدث
- MySQL 5.7 أو أحدث
- Apache/Nginx
- Composer
- Node.js (اختياري للبناء)

### خطوات التثبيت

1. **استنساخ المستودع**:
   ```bash
   git clone https://github.com/yourusername/asala-center.git
   cd AsalaCenter
   ```

2. **تثبيت تبعيات PHP**:
   ```bash
   composer install
   ```

3. **تثبيت تبعيات Node.js (اختياري)**:
   ```bash
   npm install
   ```

4. **نسخ ملف الإعدادات**:
   ```bash
   cp env.example .env
   ```

5. **تعديل إعدادات قاعدة البيانات**:
   - افتح ملف `.env`
   - عدل إعدادات قاعدة البيانات:
   ```env
   DB_HOST=localhost
   DB_NAME=asala_center
   DB_USER=root
   DB_PASS=your_password
   ```

6. **إنشاء قاعدة البيانات**:
   ```bash
   mysql -u root -p < database/schema.sql
   ```

7. **تعيين الأذونات**:
   ```bash
   chmod 755 uploads/
   chmod 644 .env
   ```

8. **بناء الأصول (اختياري)**:
   ```bash
   npm run build
   ```

## 🚀 التشغيل

### بيئة التطوير
```bash
# تشغيل خادم PHP المدمج
php -S localhost:8000

# أو استخدام XAMPP/WAMP
# ضع المشروع في مجلد htdocs
```

### الوصول للموقع
- الموقع الرئيسي: `http://localhost:8000`
- لوحة التحكم: `http://localhost:8000/admin`
- بيانات تسجيل الدخول الافتراضية:
  - البريد الإلكتروني: `admin@asalacenter.com`
  - كلمة المرور: `password`

## 🛠 أوامر مفيدة

```bash
# بناء الأصول للانتاج
npm run build

# مراقبة التغييرات في التطوير
npm run dev

# تشغيل الاختبارات
composer test

# تحديث التبعيات
composer update
npm update
```

## 🔧 الإعدادات المتقدمة

### إعدادات Apache
تأكد من تفعيل الوحدات التالية:
```apache
mod_rewrite
mod_headers
mod_deflate
mod_expires
```

### إعدادات PHP
```ini
upload_max_filesize = 10M
post_max_size = 10M
max_execution_time = 300
memory_limit = 256M
```

### إعدادات MySQL
```sql
SET GLOBAL sql_mode = "STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO";
```

## 📊 الميزات المتقدمة

### نظام اللغات
- دعم كامل للعربية والإنجليزية
- تبديل تلقائي للاتجاه (RTL/LTR)
- ترجمة ديناميكية للمحتوى

### الأمان
- حماية من XSS و CSRF
- تشفير كلمات المرور
- تحقق من صحة المدخلات
- حماية الملفات المرفوعة

### الأداء
- ضغط الملفات
- التخزين المؤقت
- تحسين الصور
- Lazy Loading

### SEO
- Meta tags ديناميكية
- Sitemap تلقائي
- Schema markup
- تحسين سرعة التحميل

## 🐛 استكشاف الأخطاء

### مشاكل شائعة

1. **خطأ في قاعدة البيانات**:
   - تأكد من صحة إعدادات الاتصال
   - تحقق من وجود قاعدة البيانات

2. **مشاكل في الصلاحيات**:
   ```bash
   chmod -R 755 uploads/
   chmod 644 .env
   ```

3. **مشاكل في mod_rewrite**:
   - تأكد من تفعيل mod_rewrite
   - تحقق من إعدادات .htaccess

## 🤝 المساهمة

نرحب بالمساهمات! يرجى اتباع الخطوات التالية:

1. Fork المشروع
2. إنشاء فرع للميزة الجديدة
3. Commit التغييرات
4. Push إلى الفرع
5. إنشاء Pull Request

## 📝 الترخيص

حقوق الطبع والنشر © 2025 **أصالة سنتر**. جميع الحقوق محفوظة.

## 📞 الدعم

للدعم الفني أو الاستفسارات:
- البريد الإلكتروني: info@asalacenter.com
- الهاتف: +966 50 123 4567
