<?php
session_start();
require_once 'config/database.php';
require_once 'includes/functions.php';

// تحديد اللغة الافتراضية
$current_lang = isset($_GET['lang']) ? $_GET['lang'] : 'ar';
$is_rtl = $current_lang === 'ar';

// تحميل ملفات اللغة
$translations = loadLanguage($current_lang);
?>
<!DOCTYPE html>
<html lang="<?php echo $current_lang; ?>" dir="<?php echo $is_rtl ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $translations['error_404']; ?> - <?php echo $translations['site_title']; ?></title>
    <meta name="robots" content="noindex, nofollow">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e40af',
                        secondary: '#f59e0b',
                        accent: '#10b981'
                    },
                    fontFamily: {
                        'arabic': ['Cairo', 'sans-serif'],
                        'english': ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="<?php echo $is_rtl ? 'font-arabic' : 'font-english'; ?> bg-gray-50">
    <!-- Header -->
    <?php include 'includes/header.php'; ?>
    
    <!-- 404 Content -->
    <section class="min-h-screen flex items-center justify-center py-20">
        <div class="container mx-auto px-4 text-center">
            <div class="max-w-2xl mx-auto">
                <!-- 404 Icon -->
                <div class="mb-8">
                    <svg class="w-32 h-32 mx-auto text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M9.172 16.172a4 4 0 015.656 0M9 12h6m-6-4h6m2 5.291A7.962 7.962 0 0112 15c-2.34 0-4.47-.881-6.08-2.33"></path>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"></path>
                    </svg>
                </div>
                
                <!-- Error Message -->
                <h1 class="text-6xl lg:text-8xl font-bold text-primary mb-6">404</h1>
                <h2 class="text-2xl lg:text-3xl font-semibold text-gray-800 mb-4">
                    <?php echo $translations['error_404']; ?>
                </h2>
                <p class="text-lg text-gray-600 mb-8 max-w-md mx-auto">
                    <?php echo $translations['page_not_found']; ?>
                </p>
                
                <!-- Action Buttons -->
                <div class="flex <?php echo $is_rtl ? 'justify-center' : 'justify-center'; ?> gap-4 mb-12">
                    <a href="index.php" class="bg-primary hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition duration-300">
                        <?php echo $translations['go_back_home']; ?>
                    </a>
                    <a href="#contact" class="border-2 border-primary text-primary hover:bg-primary hover:text-white px-8 py-3 rounded-lg font-semibold transition duration-300">
                        <?php echo $translations['menu_contact']; ?>
                    </a>
                </div>
                
                <!-- Search Box -->
                <div class="max-w-md mx-auto">
                    <form class="flex gap-2">
                        <input type="text" placeholder="<?php echo $translations['search_placeholder']; ?>" 
                               class="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
                        <button type="submit" class="bg-secondary hover:bg-yellow-600 text-white px-6 py-3 rounded-lg font-semibold transition duration-300">
                            <?php echo $translations['search']; ?>
                        </button>
                    </form>
                </div>
                
                <!-- Quick Links -->
                <div class="mt-12">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">
                        <?php echo $translations['quick_links']; ?>
                    </h3>
                    <div class="flex <?php echo $is_rtl ? 'justify-center' : 'justify-center'; ?> gap-6 flex-wrap">
                        <a href="index.php" class="text-primary hover:text-blue-700 transition duration-300">
                            <?php echo $translations['menu_home']; ?>
                        </a>
                        <a href="#services" class="text-primary hover:text-blue-700 transition duration-300">
                            <?php echo $translations['menu_services']; ?>
                        </a>
                        <a href="#about" class="text-primary hover:text-blue-700 transition duration-300">
                            <?php echo $translations['menu_about']; ?>
                        </a>
                        <a href="#projects" class="text-primary hover:text-blue-700 transition duration-300">
                            <?php echo $translations['menu_projects']; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
    
    <!-- Custom JavaScript -->
    <script src="assets/js/main.js"></script>
</body>
</html>

