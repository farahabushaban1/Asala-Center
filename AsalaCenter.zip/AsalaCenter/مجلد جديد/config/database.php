<?php
// إعدادات قاعدة البيانات
define('DB_HOST', 'localhost');
define('DB_NAME', 'asala_center');
define('DB_USER', 'root');
define('DB_PASS', '');

// إنشاء اتصال قاعدة البيانات
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage());
}

// إعدادات الموقع
define('SITE_URL', 'http://localhost/AsalaCenter');
define('SITE_NAME', 'أصالة سنتر');
define('SITE_EMAIL', 'info@asalacenter.com');

// إعدادات الأمان
define('SECRET_KEY', 'your-secret-key-here');
define('SESSION_TIMEOUT', 3600); // ساعة واحدة
?>

