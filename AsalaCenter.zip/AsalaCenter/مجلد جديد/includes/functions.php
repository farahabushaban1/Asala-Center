<?php
/**
 * دوال مساعدة للموقع
 */

/**
 * تحميل ملفات اللغة
 */
function loadLanguage($lang = 'ar') {
    $lang_file = "languages/{$lang}.php";
    
    if (file_exists($lang_file)) {
        return include $lang_file;
    } else {
        // إرجاع اللغة العربية كافتراضي
        return include 'languages/ar.php';
    }
}

/**
 * تنظيف النصوص المدخلة
 */
function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

/**
 * التحقق من صحة البريد الإلكتروني
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * إنشاء رابط آمن
 */
function createSecureLink($url, $params = []) {
    $base_url = rtrim($url, '/');
    if (!empty($params)) {
        $base_url .= '?' . http_build_query($params);
    }
    return $base_url;
}

/**
 * تحويل التاريخ إلى التنسيق العربي
 */
function formatDateArabic($date) {
    $months = [
        'January' => 'يناير',
        'February' => 'فبراير',
        'March' => 'مارس',
        'April' => 'أبريل',
        'May' => 'مايو',
        'June' => 'يونيو',
        'July' => 'يوليو',
        'August' => 'أغسطس',
        'September' => 'سبتمبر',
        'October' => 'أكتوبر',
        'November' => 'نوفمبر',
        'December' => 'ديسمبر'
    ];
    
    $english_date = date('F j, Y', strtotime($date));
    $arabic_date = str_replace(array_keys($months), array_values($months), $english_date);
    
    return $arabic_date;
}

/**
 * إنشاء كلمة مرور قوية
 */
function generateStrongPassword($length = 12) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+';
    $password = '';
    
    for ($i = 0; $i < $length; $i++) {
        $password .= $chars[rand(0, strlen($chars) - 1)];
    }
    
    return $password;
}

/**
 * رفع الملفات
 */
function uploadFile($file, $destination, $allowed_types = ['jpg', 'jpeg', 'png', 'gif']) {
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    // التحقق من نوع الملف
    if (!in_array($file_extension, $allowed_types)) {
        return ['success' => false, 'message' => 'نوع الملف غير مسموح به'];
    }
    
    // التحقق من حجم الملف (5MB كحد أقصى)
    if ($file['size'] > 5 * 1024 * 1024) {
        return ['success' => false, 'message' => 'حجم الملف كبير جداً'];
    }
    
    // إنشاء اسم فريد للملف
    $filename = uniqid() . '.' . $file_extension;
    $filepath = $destination . '/' . $filename;
    
    // رفع الملف
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return ['success' => true, 'filename' => $filename, 'filepath' => $filepath];
    } else {
        return ['success' => false, 'message' => 'فشل في رفع الملف'];
    }
}

/**
 * إرسال بريد إلكتروني
 */
function sendEmail($to, $subject, $message, $headers = '') {
    $default_headers = "From: " . SITE_EMAIL . "\r\n";
    $default_headers .= "Reply-To: " . SITE_EMAIL . "\r\n";
    $default_headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    $headers = $headers ? $headers : $default_headers;
    
    return mail($to, $subject, $message, $headers);
}

/**
 * تسجيل الدخول
 */
function loginUser($email, $password) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND status = 'active'");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['login_time'] = time();
        
        return true;
    }
    
    return false;
}

/**
 * تسجيل الخروج
 */
function logoutUser() {
    session_destroy();
    return true;
}

/**
 * التحقق من تسجيل الدخول
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && (time() - $_SESSION['login_time']) < SESSION_TIMEOUT;
}

/**
 * التحقق من صلاحيات المستخدم
 */
function hasPermission($permission) {
    if (!isLoggedIn()) {
        return false;
    }
    
    // يمكن إضافة منطق التحقق من الصلاحيات هنا
    return $_SESSION['user_role'] === 'admin';
}

/**
 * إعادة توجيه المستخدم
 */
function redirect($url) {
    header("Location: " . $url);
    exit();
}

/**
 * عرض رسالة للمستخدم
 */
function showMessage($message, $type = 'info') {
    $_SESSION['message'] = [
        'text' => $message,
        'type' => $type
    ];
}

/**
 * الحصول على رسالة المستخدم
 */
function getMessage() {
    if (isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
        unset($_SESSION['message']);
        return $message;
    }
    return null;
}
?>

