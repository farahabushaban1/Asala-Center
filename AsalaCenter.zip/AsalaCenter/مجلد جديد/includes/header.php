<?php
// تحديد اللغة الحالية
$current_lang = isset($_GET['lang']) ? $_GET['lang'] : 'ar';
$is_rtl = $current_lang === 'ar';
$translations = loadLanguage($current_lang);
?>
<header class="bg-white shadow-lg sticky top-0 z-50">
    <div class="container mx-auto px-4">
        <div class="flex justify-between items-center py-4">
            <!-- Logo -->
            <div class="flex items-center">
                <a href="index.php" class="text-2xl font-bold text-primary">
                    <?php echo $translations['site_title']; ?>
                </a>
            </div>
            
            <!-- Desktop Menu -->
            <nav class="hidden lg:flex items-center space-x-8 <?php echo $is_rtl ? 'space-x-reverse' : ''; ?>">
                <a href="index.php" class="text-gray-700 hover:text-primary font-medium transition duration-300">
                    <?php echo $translations['menu_home']; ?>
                </a>
                <a href="#services" class="text-gray-700 hover:text-primary font-medium transition duration-300">
                    <?php echo $translations['menu_services']; ?>
                </a>
                <a href="#about" class="text-gray-700 hover:text-primary font-medium transition duration-300">
                    <?php echo $translations['menu_about']; ?>
                </a>
                <a href="#projects" class="text-gray-700 hover:text-primary font-medium transition duration-300">
                    <?php echo $translations['menu_projects']; ?>
                </a>
                <a href="#contact" class="text-gray-700 hover:text-primary font-medium transition duration-300">
                    <?php echo $translations['menu_contact']; ?>
                </a>
            </nav>
            
            <!-- Language Switcher & Mobile Menu Button -->
            <div class="flex items-center space-x-4 <?php echo $is_rtl ? 'space-x-reverse' : ''; ?>">
                <!-- Language Switcher -->
                <div class="relative">
                    <button id="languageBtn" class="flex items-center space-x-2 <?php echo $is_rtl ? 'space-x-reverse' : ''; ?> text-gray-700 hover:text-primary transition duration-300">
                        <span class="text-sm font-medium">
                            <?php echo $current_lang === 'ar' ? 'العربية' : 'English'; ?>
                        </span>
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </button>
                    
                    <!-- Language Dropdown -->
                    <div id="languageDropdown" class="absolute top-full right-0 mt-2 w-32 bg-white rounded-lg shadow-lg border border-gray-200 hidden">
                        <a href="?lang=ar" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-t-lg">
                            العربية
                        </a>
                        <a href="?lang=en" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-b-lg">
                            English
                        </a>
                    </div>
                </div>
                
                <!-- Admin/Login Button -->
                <?php if (isLoggedIn()): ?>
                    <a href="admin/dashboard.php" class="bg-primary text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition duration-300">
                        <?php echo $translations['menu_admin']; ?>
                    </a>
                <?php else: ?>
                    <a href="admin/login.php" class="bg-primary text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 transition duration-300">
                        <?php echo $translations['menu_login']; ?>
                    </a>
                <?php endif; ?>
                
                <!-- Mobile Menu Button -->
                <button id="mobileMenuBtn" class="lg:hidden text-gray-700 hover:text-primary">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>
            </div>
        </div>
        
        <!-- Mobile Menu -->
        <div id="mobileMenu" class="lg:hidden hidden">
            <nav class="py-4 border-t border-gray-200">
                <div class="flex flex-col space-y-4">
                    <a href="index.php" class="text-gray-700 hover:text-primary font-medium transition duration-300">
                        <?php echo $translations['menu_home']; ?>
                    </a>
                    <a href="#services" class="text-gray-700 hover:text-primary font-medium transition duration-300">
                        <?php echo $translations['menu_services']; ?>
                    </a>
                    <a href="#about" class="text-gray-700 hover:text-primary font-medium transition duration-300">
                        <?php echo $translations['menu_about']; ?>
                    </a>
                    <a href="#projects" class="text-gray-700 hover:text-primary font-medium transition duration-300">
                        <?php echo $translations['menu_projects']; ?>
                    </a>
                    <a href="#contact" class="text-gray-700 hover:text-primary font-medium transition duration-300">
                        <?php echo $translations['menu_contact']; ?>
                    </a>
                </div>
            </nav>
        </div>
    </div>
</header>

<script>
// Language Dropdown Toggle
document.getElementById('languageBtn').addEventListener('click', function() {
    const dropdown = document.getElementById('languageDropdown');
    dropdown.classList.toggle('hidden');
});

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const languageBtn = document.getElementById('languageBtn');
    const dropdown = document.getElementById('languageDropdown');
    
    if (!languageBtn.contains(event.target) && !dropdown.contains(event.target)) {
        dropdown.classList.add('hidden');
    }
});

// Mobile Menu Toggle
document.getElementById('mobileMenuBtn').addEventListener('click', function() {
    const mobileMenu = document.getElementById('mobileMenu');
    mobileMenu.classList.toggle('hidden');
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});
</script>

